const express = require('express');
const app = express();
const cors = require('cors');
const dotenv = require('dotenv');
const { getPool } = require('./db');

dotenv.config();

app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: false }));

const pool = getPool();

pool.getConnection()
    .then(conn => {
        console.log("MySQL Connected");
        conn.release();
    })
    .catch(err => {
        console.log("DB Error:", err);
    });


app.post('/api/notes', async (req, res) => {
    try {
        const { judul, isi } = req.body;

        const [result] = await pool.query(
            "INSERT INTO notes (judul, isi) VALUES (?, ?)",
            [judul, isi]
        );

        res.json({ success: true, id: result.insertId });

    } catch (err) {
        console.log(err);
        res.status(500).json({ success: false });
    }
});


app.get('/api/notes', async (req, res) => {
    try {
        const [rows] = await pool.query(
            "SELECT * FROM notes ORDER BY id DESC"
        );

        res.json(rows);

    } catch (err) {
        res.status(500).json([]);
    }
});


app.get('/api/notes/:id', async (req, res) => {
    try {
        const { id } = req.params;

        const [rows] = await pool.query(
            "SELECT * FROM notes WHERE id = ?",
            [id]
        );

        res.json(rows[0]);

    } catch (err) {
        res.status(500).json({});
    }
});

// ================= UPDATE =================
app.put('/api/notes/:id', async (req, res) => {
    try {
        const { id } = req.params;
        const { judul, isi } = req.body;

        await pool.query(
            "UPDATE notes SET judul=?, isi=? WHERE id=?",
            [judul, isi, id]
        );

        res.json({ success: true });

    } catch (err) {
        res.status(500).json({ success: false });
    }
});

// ================= DELETE =================
app.delete('/api/notes/:id', async (req, res) => {
    try {
        const { id } = req.params;

        await pool.query(
            "DELETE FROM notes WHERE id=?",
            [id]
        );

        res.json({ success: true });

    } catch (err) {
        res.status(500).json({ success: false });
    }
});

// ================= RUN =================
app.listen(process.env.PORT || 3000, () => {
    console.log("Server running...");
});